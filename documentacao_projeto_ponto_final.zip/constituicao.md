# Constituição do Projeto: Sistema de Controle de Ponto e Banco de Horas

Este documento define os princípios inegociáveis do projeto, definidos exclusivamente pela equipe, que guiarão todas as etapas de desenvolvimento.

**P1. Transparência Total** 
O colaborador deve ter acesso claro e simplificado às suas horas computadas e às regras que regem os cálculos do seu banco de horas.

**P2. Acessibilidade e Inclusão** 
O sistema deve adaptar-se ativamente às necessidades visuais (como daltonismo e contraste) e de idioma dos usuários.

**P3. Auditoria e Controle** 
Nenhuma alteração manual ou inserção retroativa de ponto será processada no saldo sem a aprovação explícita e registrada de um gestor.

**P4. Simplicidade Mobile-First** 
A interface do colaborador deve priorizar a agilidade: a ação principal (bater o ponto) deve exigir no máximo dois toques na tela.