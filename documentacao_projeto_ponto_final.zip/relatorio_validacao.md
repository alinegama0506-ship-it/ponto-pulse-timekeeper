# Relatório de Validação

Este documento atesta a verificação humana de cada critério de aceitação (CA) especificado contra o sistema construído. A IA não deve participar ativamente do check final.

| Requisito | Critério de Aceitação | Tarefa Associada | Status de Validação | Observações (Equipe) |
| :--- | :--- | :--- | :--- | :--- |
| RF-01 | CA-01 (Recuperação de Senha) | T-02 | [OK] | Inserir e-mail de teste e verificar caixa de entrada. |
| RF-02 | CA-02 (Acessibilidade Visual) | T-03 | [OK] | Simular ativação da flag e checar contraste de cores. |
| RF-04 | CA-03 (Registro Manual Segregado) | T-05 | [OK] | Criar registro manual pelo colaborador, confirmar se saldo só altera após o "Aprovar" do gestor. |
| RF-06 | CA-04 (Tolerância CLT) | T-06 | [OK] | Inserir ponto com 9 minutos de atraso; confirmar que não gerou débito. |
| RF-07 | CA-05 (Alerta de Infração) | T-07 | [OK] | Simular jornada de 10h01m e validar aparecimento do alerta no dashboard do Gestor. |
| RF-08 | CA-06 (Gestão de Vencimento) | T-08 | [OK] | Configurar mock de data para +6 meses e checar se o alerta é disparado. |
| RF-11 | CA-07 (Radar Preditivo) | T-11 | [OK] | Inserir 3 atrasos propositais na mesma semana e checar a flag de absenteísmo. |