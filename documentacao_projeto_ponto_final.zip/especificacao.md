# Documento de Especificação: Sistema de Controle de Ponto e Banco de Horas

## 1. Contexto e Problemática
Em muitas empresas, o controle de jornada e banco de horas é feito por planilhas manuais ou sistemas engessados, dificultando a visão em tempo real para o colaborador e sobrecarregando o RH. Propomos o desenvolvimento de um Sistema de Processamento de Transações (SPT) em formato web app responsivo, focado na experiência mobile, que centralize marcações, calcule saldos automaticamente com base na CLT e forneça indicadores gerenciais preditivos.

## 2. Usuários do Sistema
* **Colaborador**: Acessa via smartphone para registrar o ponto com um clique, acompanhar seu saldo de horas, verificar prazos de vencimento do banco e consultar as regras da empresa.
* **Gestor / RH**: Acessa via desktop/tablet para gerenciar a equipe, aprovar ajustes de ponto, parametrizar regras trabalhistas e monitorar indicadores estratégicos (absenteísmo, top devedores, horas a vencer).

## 3. Escopo
* **Dentro do escopo**: Autenticação de usuários, registro de ponto em tempo real via interface responsiva, cálculo automático de saldo com regras de tolerância, gestão de vencimento de horas, dashboard operacional (colaborador), dashboard estratégico (gestor), configurações de acessibilidade (modo escuro, alto contraste para daltonismo) e aba de transparência de regras de negócio.
* **Fora do escopo**: Processamento financeiro de folha de pagamento, integração com sistemas de contabilidade de terceiros, biometria facial, e cálculo de adicional noturno ou insalubridade.

## 4. Requisitos Funcionais (RF) - Formato EARS
* **RF-01**: Quando um usuário acessar o sistema, o sistema deve exibir o login com perfis separados (Colaborador e Gestor) e fornecer um fluxo de recuperação de senha.
* **RF-02**: O sistema deve permitir alternar o tema (claro/escuro), idioma (PT/EN) e ativar filtro de daltonismo através de um menu de configurações.
* **RF-03**: Quando acessado via mobile, o sistema deve exibir uma interface otimizada em no máximo dois toques para o registro de ponto (entrada, intervalos e saída).
* **RF-04**: Se o colaborador esquecer de registrar um ponto, o sistema deve permitir a solicitação de inclusão manual, direcionando-a para uma fila de aprovação do Gestor.
* **RF-05**: O sistema deve possuir uma "Aba de Transparência" onde as regras (tolerância, validade, limites diários) ficam disponíveis para leitura pelos colaboradores e edição pelos gestores.
* **RF-06**: Sempre que o saldo diário for calculado, o sistema deve desconsiderar atrasos ou adiantamentos de até 10 minutos (Tolerância configurável da CLT).
* **RF-07**: Se a jornada diária do colaborador ultrapassar 10 horas trabalhadas, o sistema deve gerar um alerta gerencial automático.
* **RF-08**: Quando o prazo de validade do banco de horas (ex: 6 meses) estiver prestes a vencer, o sistema deve enviar um alerta ao colaborador e ao gestor.
* **RF-09**: O sistema deve exibir no Dashboard do Colaborador o saldo atualizado, horários batidos no dia, status de ajustes pendentes e contagem regressiva para o vencimento de horas.
* **RF-10**: O sistema deve exibir no Dashboard do Gestor a fila de aprovação de ajustes de pontos e uma tabela listando os "Top Devedores/Credores" de horas.
* **RF-11**: O sistema deve exibir no Dashboard do Gestor um Radar de Absenteísmo, destacando funcionários com faltas recorrentes ou que quebram a regra de tolerância repetidamente.

## 5. Critérios de Aceitação (CA)
* **CA-01 (Recuperação de Senha)**: Dado que o usuário esqueceu a senha, quando solicitar a recuperação inserindo seu e-mail, então o sistema deve enviar um link seguro de redefinição.
* **CA-02 (Acessibilidade Visual)**: Dado que um usuário acessou as configurações, quando ativar o modo para daltonismo, então o sistema deve alterar a paleta de cores (ex: de vermelho/verde para azul/laranja).
* **CA-03 (Registro Manual Segregado)**: Dado que o colaborador esqueceu de bater o ponto de saída, quando solicitar a inserção manual das "18:00", então o saldo não deve ser atualizado até que o gestor clique ativamente em "Aprovar".
* **CA-04 (Tolerância CLT)**: Dado que a regra de tolerância configurada é de 10 minutos, quando o colaborador com entrada prevista para 08:00 registrar o ponto às 08:09, então o sistema não computará saldo negativo.
* **CA-05 (Alerta de Infração)**: Dado que o limite diário está configurado em 10h, quando o tempo trabalhado do colaborador atingir 10h01, então o painel do gestor exibirá imediatamente um alerta de quebra de regra contratual.
* **CA-06 (Gestão de Vencimento)**: Dado que o prazo de validade configurado é de 6 meses, quando o mês atual atingir esse prazo em relação a um acúmulo anterior, então o colaborador e o gestor receberão um alerta de "Horas a vencer".
* **CA-07 (Radar Preditivo)**: Dado que o gestor acessa o dashboard estratégico, quando um funcionário acumular 3 atrasos acima da tolerância na mesma semana, então o nome do colaborador aparecerá na área de "Risco de Absenteísmo".