# Planejamento Técnico e Arquitetura

## 1. Decisões Técnicas e Ferramentas
A abordagem de desenvolvimento adotada é a Spec-Driven, com o auxílio de IA.
* **Prototipação e Frontend**: Claude foi utilizado na fase inicial para a estruturação lógica, criação de telas mockadas e fluxo de interface.
* **Backend, Layout e Integração**: Lovable foi empregado para consolidar o layout responsivo, construir as rotas de backend (autenticação, cálculo e banco de dados) e realizar o deploy e integração contínua diretamente com o repositório no GitHub.

## 2. Estrutura de Dados (Entidades Principais)
* **Usuário**: `ID`, `Nome`, `Email`, `SenhaHash`, `Perfil (Colaborador/Gestor)`, `PreferenciasAcessibilidade`
* **RegistroPonto**: `ID`, `UsuarioID`, `DataHora`, `Tipo (Entrada, Saida, Intervalo)`, `Metodo (Auto, Manual)`
* **AjustePonto**: `ID`, `RegistroPontoID`, `Justificativa`, `Status (Pendente, Aprovado, Recusado)`, `GestorAprovadorID`
* **RegrasEmpresa**: `ID`, `ToleranciaMinutos`, `LimiteDiarioHoras`, `MesesValidadeBanco`

## 3. Mapeamento de Riscos e Mitigações
* **Risco 1**: Falta de conectividade no momento de registrar o ponto no mobile.
  * *Mitigação*: Armazenamento em cache local (Local Storage) da requisição com timestamp validado, sincronizando assim que a internet retornar.
* **Risco 2**: Edição concorrente da mesma regra de tolerância por dois gestores diferentes.
  * *Mitigação*: Bloqueio otimista no banco de dados, avisando o segundo gestor que a regra já foi atualizada.