# Relatório Final e Registro de Uso de IA

## 1. Método e Decisões
Seguimos a abordagem *Spec-Driven* sugerida para o projeto. O problema escolhido possuía clara aderência a um SPT (Sistema de Processamento de Transações), registrando dados estruturados essenciais para operações de RH. A divisão de tarefas garantiu que a lógica crítica de negócio (tolerâncias e aprovações) fosse documentada de forma independente antes de qualquer código ser gerado.

## 2. Uso Responsável da IA
* **Divisão de Papéis**: A equipe formulou os princípios (Constituição), o escopo (Especificação) e foi a única responsável pelos testes manuais (Validação).
* **Assistentes Utilizados**:
  * **Claude**: Auxiliou na transcrição dos requisitos para o padrão EARS, formatação de mockups conceituais de UI e debate de estrutura inicial.
  * **Lovable**: Atuou como executor (*Vibe Coding/Gerador*) na fase de implementação (backend, banco de dados, frontend responsivo e integração contínua com o GitHub). 
* **Revisão Humana**: Todas as lógicas geradas pelo Lovable, especialmente o motor de cálculo da tolerância (CA-04) e a segregação de perfil (CA-03), foram inspecionadas pela equipe para garantir aderência à Especificação, não aceitando lógicas "padrões" que a IA tentasse impor.

## 3. Aprendizados
O desenvolvimento demonstrou que a especificação clara via critérios "Dado/Quando/Então" foi vital para corrigir "alucinações" das ferramentas low-code durante a geração do motor de banco de horas, garantindo um produto rigoroso, entregável no prazo do semestre e alinhado aos critérios de qualidade exigidos.