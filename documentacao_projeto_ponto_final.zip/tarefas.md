# Estrutura Analítica do Projeto (Tarefas)

A decomposição abaixo organiza o trabalho do sistema rastreando requisitos e critérios de aceitação, garantindo que a implementação possa ser executada passo a passo pela IA com supervisão humana.

* **T-01**: Configurar repositório no GitHub e setup inicial de ambiente via Lovable (Pré-requisito).
* **T-02**: Criar modelo de banco de dados para Usuários e implementar fluxo de Autenticação e Recuperação de Senha. (Rastreia: RF-01, CA-01)
* **T-03**: Desenvolver menu de configurações (Tema, Idioma, Daltonismo) vinculado ao perfil do usuário. (Rastreia: RF-02, CA-02)
* **T-04**: Implementar interface mobile-first para bater ponto com gravação no banco de dados. (Rastreia: RF-03)
* **T-05**: Desenvolver o fluxo de inserção manual (Formulário do Colaborador + Fila de Aprovação do Gestor). (Rastreia: RF-04, CA-03)
* **T-06**: Construir a lógica de motor de cálculo de saldo de horas e aplicação da tolerância de 10 min. (Rastreia: RF-06, CA-04)
* **T-07**: Implementar motor de regras de alertas (Limite de 10h diárias). (Rastreia: RF-07, CA-05)
* **T-08**: Criar sistema de gestão de validade de saldo de horas (Vencimento em 6 meses). (Rastreia: RF-08, CA-06)
* **T-09**: Construir Dashboard do Colaborador (Saldo, Histórico diário, Prazos). (Rastreia: RF-09)
* **T-10**: Construir Dashboard do Gestor (Tabelas de devedores/credores e fila de aprovação). (Rastreia: RF-10)
* **T-11**: Implementar o "Radar de Absenteísmo" no Dashboard do Gestor. (Rastreia: RF-11, CA-07)
* **T-12**: Criar e popular a "Aba de Transparência" vinculada aos parâmetros do sistema. (Rastreia: RF-05)